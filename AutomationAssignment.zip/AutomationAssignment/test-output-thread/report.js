$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "bae7f3f2-0db6-4bd4-9260-4dc8b04d95c3",
    "feature": "W3Schoos Online Tutorials",
    "scenario": "Java Class Tutorials",
    "start": 1667860914351,
    "group": 1,
    "content": "",
    "tags": "",
    "end": 1667860925262,
    "className": "passed"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});